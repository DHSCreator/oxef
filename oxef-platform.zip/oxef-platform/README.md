# OXEF — Lead Operations Platform

A B2B/B2C lead automation dashboard: one place where leads from your
website form, email, Instagram (DMs + comments), and Telegram bot land,
get tagged, followed up, and booked.

## Stack

- **Next.js 16** (App Router) — UI + API routes
- **Drizzle ORM + better-sqlite3** — local file DB, zero external services to start.
  Swap to Postgres later (see below) without touching the schema much.
- **NextAuth v5** (Auth.js) — email/password login (credentials provider), JWT sessions
- **Tailwind CSS 4**

## What's built

- `/api/intake` — the single front door for inbound leads from **any** channel
  (website form, email parser, Instagram DM/comment bot, Telegram bot). Protected
  by `INTAKE_API_KEY` sent as `x-api-key` header. This is the endpoint your n8n
  workflows should POST to.
- `/api/leads`, `/api/leads/[id]`, `/api/leads/[id]/booking` — internal API used
  by the dashboard (session-protected)
- `/dashboard` — overview with lead counts (new / follow-up / booked / won)
- `/dashboard/leads` — CRM table, filterable by `?mode=B2B` or `?mode=B2C`
- `/dashboard/leads/[id]` — lead detail: status changer, notes, booking scheduler,
  full activity log
- Auth: `/login`, middleware-protected `/dashboard/*`

## Running it locally

```bash
npm install
npm run db:push        # creates the sqlite tables
npm run db:seed        # creates an admin user + 2 sample leads
npm run dev
```

Open http://localhost:3000, sign in with whatever you set as
`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` (defaults: `admin@oxef.io` /
`changeme123` — **change this before deploying**).

## Environment variables (`.env`)

```
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="<random string — generate with: openssl rand -base64 32>"
NEXTAUTH_URL="http://localhost:3000"       # your real domain in production
AUTH_TRUST_HOST="true"                      # required by NextAuth v5
INTAKE_API_KEY="<random string — this is your webhook secret>"
SEED_ADMIN_EMAIL="admin@oxef.io"
SEED_ADMIN_PASSWORD="changeme123"
```

A `.env` with working defaults is already included for local testing.
Generate real random values for `NEXTAUTH_SECRET` and `INTAKE_API_KEY` before
going live — `openssl rand -base64 32` works well for both.

## Wiring up your lead channels (n8n)

Point each of your n8n workflows' final HTTP Request node at:

```
POST https://your-domain.com/api/intake
Headers: x-api-key: <your INTAKE_API_KEY>
Body (JSON):
{
  "mode": "B2B" | "B2C",
  "source": "WEBSITE_FORM" | "EMAIL" | "INSTAGRAM_DM" | "INSTAGRAM_COMMENT" | "TELEGRAM_BOT" | "MANUAL" | "OTHER",
  "name": "optional",
  "email": "optional",
  "phone": "optional",
  "company": "optional (B2B)",
  "industry": "optional",
  "rawMessage": "optional — the original message text, useful for context"
}
```

Every call creates a lead with status `NEW` and logs an activity entry. From
there, your follow-up/booking agent (or a human) can call:

- `PATCH /api/leads/:id` with `{ "status": "FOLLOW_UP" }` etc. — or just use
  the dashboard
- `POST /api/leads/:id/booking` with `{ "scheduledAt": "<ISO date>" }` to
  create a booking (this also flips the lead's status to `BOOKED`)

Both of these internal endpoints require a logged-in session, not the API key
— they're meant for the dashboard UI. If you want n8n to update statuses
directly too, the cleanest path is to add a second API-key-protected route
mirroring `/api/intake`'s pattern.

## Moving off SQLite to Postgres (for real multi-user / serverless deploys)

SQLite is great for getting this running today, but a single file won't work
well on serverless platforms (Vercel) where the filesystem isn't persistent
across invocations. When you're ready:

1. Create a Postgres database (Neon, Supabase, or Railway all have free tiers)
2. `npm install drizzle-orm pg` (keep drizzle-orm, add `pg`; you can remove
   `better-sqlite3` after)
3. In `src/db/index.ts`, swap the `better-sqlite3` driver import for
   `drizzle-orm/node-postgres`, and point it at your Postgres `DATABASE_URL`
4. In `drizzle.config.ts`, change `dialect: "sqlite"` to `dialect: "postgresql"`
5. In `src/db/schema.ts`, swap `sqliteTable` → `pgTable` and adjust column
   types (`integer(..., { mode: "timestamp" })` → `timestamp(...)`)
6. `npm run db:push` again against the new database

The route/API code doesn't need to change — only the schema and `db/index.ts`.

## Deploying (Vercel)

1. Push this repo to GitHub
2. Import it in Vercel
3. Set the environment variables above in the Vercel project settings
   (use your Postgres `DATABASE_URL` once migrated — see above)
4. Set `NEXTAUTH_URL` to your production domain
5. Deploy. Run `npm run db:push && npm run db:seed` once against production
   to create your first admin user.

## What's intentionally left simple (next steps)

- No signup flow — users are created via the seed script or directly in the
  DB for now. Add an invite/signup flow when you have more than one agent.
- Role-based access (ADMIN vs AGENT) exists in the schema but isn't enforced
  in the UI yet.
- No email/SMS sending — the "follow-up" step is tracked as a status + note;
  actually sending still happens in your n8n workflow, which can call back
  into `/api/leads/:id` to log what it did.
- Booking is a single date/time field with a `confirmed` flag — no calendar
  sync. Wire that to Google Calendar from n8n if needed.
