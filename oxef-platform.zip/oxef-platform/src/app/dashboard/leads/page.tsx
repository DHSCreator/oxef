import { db } from "@/db";
import { leads } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { LeadsTable } from "@/components/leads-table";
import { NewLeadForm } from "@/components/new-lead-form";

export default async function LeadsPage({
  searchParams,
}: {
  searchParams: Promise<{ mode?: string; status?: string }>;
}) {
  const { mode, status } = await searchParams;

  const conditions = [];
  if (mode === "B2B" || mode === "B2C") conditions.push(eq(leads.mode, mode));
  if (status) conditions.push(eq(leads.status, status as "NEW"));

  const rows = await db
    .select()
    .from(leads)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(leads.createdAt));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold mb-1">
            Leads {mode ? `· ${mode}` : ""} {status ? `· ${status}` : ""}
          </h1>
          <p className="text-sm" style={{ color: "var(--text-dim)" }}>
            {rows.length} lead{rows.length === 1 ? "" : "s"}
          </p>
        </div>
        <NewLeadForm />
      </div>

      <LeadsTable leads={rows} />
    </div>
  );
}
