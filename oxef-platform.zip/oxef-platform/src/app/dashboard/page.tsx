import { db } from "@/db";
import { leads } from "@/db/schema";
import Link from "next/link";

export default async function OverviewPage() {
  const all = await db.select().from(leads);

  const byMode = {
    B2B: all.filter((l) => l.mode === "B2B").length,
    B2C: all.filter((l) => l.mode === "B2C").length,
  };
  const newLeads = all.filter((l) => l.status === "NEW").length;
  const inFollowUp = all.filter((l) => l.status === "FOLLOW_UP").length;
  const booked = all.filter((l) => l.status === "BOOKED").length;
  const won = all.filter((l) => l.status === "WON").length;

  const stats: { label: string; value: number; tone?: string }[] = [
    { label: "New leads", value: newLeads, tone: "var(--signal)" },
    { label: "In follow-up", value: inFollowUp },
    { label: "Booked", value: booked, tone: "var(--good)" },
    { label: "Won", value: won, tone: "var(--good)" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Overview</h1>
      <p className="text-sm mb-8" style={{ color: "var(--text-dim)" }}>
        {all.length} total leads · {byMode.B2B} B2B · {byMode.B2C} B2C
      </p>

      <div className="grid grid-cols-4 gap-4 mb-10">
        {stats.map((s) => (
          <div
            key={s.label}
            className="p-5 rounded-lg border"
            style={{ borderColor: "var(--line)", background: "var(--panel)" }}
          >
            <p className="text-3xl font-semibold mb-1" style={{ color: s.tone }}>
              {s.value}
            </p>
            <p className="text-sm" style={{ color: "var(--text-dim)" }}>
              {s.label}
            </p>
          </div>
        ))}
      </div>

      {newLeads > 0 && (
        <Link
          href="/dashboard/leads?status=NEW"
          className="inline-block px-4 py-2 rounded text-sm font-medium"
          style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
        >
          Work the {newLeads} new lead{newLeads === 1 ? "" : "s"} →
        </Link>
      )}

      {all.length === 0 && (
        <div className="p-6 rounded-lg border" style={{ borderColor: "var(--line)" }}>
          <p style={{ color: "var(--text-dim)" }}>
            No leads yet. Point your intake sources (website form, email
            parser, Instagram, Telegram bot via n8n) at{" "}
            <code className="mono">POST /api/intake</code> with your{" "}
            <code className="mono">INTAKE_API_KEY</code>, or{" "}
            <Link href="/dashboard/leads" className="underline">
              add one manually
            </Link>
            .
          </p>
        </div>
      )}
    </div>
  );
}
