import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/db";
import { leads, activities, LEAD_STATUSES } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const lead = db.select().from(leads).where(eq(leads.id, id)).get();
  if (!lead) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const log = await db
    .select()
    .from(activities)
    .where(eq(activities.leadId, id));

  return NextResponse.json({ lead, activities: log });
}

const UpdateSchema = z.object({
  status: z.enum(LEAD_STATUSES).optional(),
  assignedToId: z.string().nullable().optional(),
  note: z.string().optional(),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = UpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { status, assignedToId, note } = parsed.data;

  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (status) updates.status = status;
  if (assignedToId !== undefined) updates.assignedToId = assignedToId;

  const [updated] = await db
    .update(leads)
    .set(updates)
    .where(eq(leads.id, id))
    .returning();

  if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (status) {
    await db.insert(activities).values({
      leadId: id,
      userId: (session.user as { id?: string })?.id,
      type: "status_change",
      message: `Status changed to ${status}`,
    });
  }
  if (note) {
    await db.insert(activities).values({
      leadId: id,
      userId: (session.user as { id?: string })?.id,
      type: "note",
      message: note,
    });
  }

  return NextResponse.json(updated);
}
