import { getToken } from "next-auth/jwt";
import { NextResponse, type NextRequest } from "next/server";

// Note: this file intentionally does NOT import "@/auth" or "@/db".
// Those pull in better-sqlite3 (a native Node module), which cannot run
// in the Edge Middleware runtime. getToken() only needs NEXTAUTH_SECRET
// to verify the session JWT, so it's safe here.

export async function middleware(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

  if (!token) {
    const loginUrl = new URL("/login", req.nextUrl.origin);
    loginUrl.searchParams.set("callbackUrl", req.nextUrl.pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"],
};
