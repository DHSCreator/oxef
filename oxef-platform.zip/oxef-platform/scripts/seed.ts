import "dotenv/config";
import bcrypt from "bcryptjs";
import { db } from "../src/db";
import { users, leads } from "../src/db/schema";

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL || "admin@oxef.io";
  const password = process.env.SEED_ADMIN_PASSWORD || "changeme123";

  const passwordHash = await bcrypt.hash(password, 10);

  await db
    .insert(users)
    .values({ name: "Admin", email, passwordHash, role: "ADMIN" })
    .onConflictDoNothing();

  await db.insert(leads).values([
    {
      mode: "B2B",
      source: "WEBSITE_FORM",
      name: "Daniyar Suleimenov",
      company: "Alatau Logistics",
      email: "daniyar@alataulogistics.kz",
      industry: "Logistics",
      status: "NEW",
    },
    {
      mode: "B2C",
      source: "INSTAGRAM_DM",
      name: "Aigerim K.",
      email: "aigerim@example.com",
      rawMessage: "Hi! Saw your ad, how much for the consultation?",
      status: "FOLLOW_UP",
    },
  ]);

  console.log(`Seeded admin: ${email} / ${password}`);
  console.log("Seeded 2 sample leads.");
}

main().then(() => process.exit(0));
