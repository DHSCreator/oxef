import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { leads, activities, LEAD_MODES, LEAD_SOURCES } from "@/db/schema";
import { z } from "zod";

// This endpoint is the single front door for every inbound lead channel:
// website form, email parser, Instagram DM/comment bot, Telegram bot (all via n8n).
// Secure it with INTAKE_API_KEY so only your automations can post leads.

const IntakeSchema = z.object({
  mode: z.enum(LEAD_MODES),
  source: z.enum(LEAD_SOURCES),
  name: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  company: z.string().optional(),
  industry: z.string().optional(),
  rawMessage: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const apiKey = req.headers.get("x-api-key");
  if (!process.env.INTAKE_API_KEY || apiKey !== process.env.INTAKE_API_KEY) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = IntakeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const data = parsed.data;

  const [lead] = await db
    .insert(leads)
    .values({
      mode: data.mode,
      source: data.source,
      name: data.name,
      email: data.email,
      phone: data.phone,
      company: data.company,
      industry: data.industry,
      rawMessage: data.rawMessage,
    })
    .returning();

  await db.insert(activities).values({
    leadId: lead.id,
    type: "lead_created",
    message: `Lead captured via ${data.source} (${data.mode})`,
  });

  return NextResponse.json({ ok: true, leadId: lead.id }, { status: 201 });
}
