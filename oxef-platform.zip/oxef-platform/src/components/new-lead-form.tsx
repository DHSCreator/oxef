"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function NewLeadForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"B2B" | "B2C">("B2B");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    await fetch("/api/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode, name, email, company, source: "MANUAL" }),
    });
    setSubmitting(false);
    setOpen(false);
    setName("");
    setEmail("");
    setCompany("");
    router.refresh();
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="px-4 py-2 rounded text-sm font-medium"
        style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
      >
        Add lead
      </button>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-center gap-2 p-3 rounded-lg border"
      style={{ borderColor: "var(--line)", background: "var(--panel)" }}
    >
      <select
        value={mode}
        onChange={(e) => setMode(e.target.value as "B2B" | "B2C")}
        className="px-2 py-1 rounded border bg-transparent text-sm"
        style={{ borderColor: "var(--line)" }}
      >
        <option value="B2B">B2B</option>
        <option value="B2C">B2C</option>
      </select>
      <input
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="px-2 py-1 rounded border bg-transparent text-sm w-32"
        style={{ borderColor: "var(--line)" }}
      />
      <input
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="px-2 py-1 rounded border bg-transparent text-sm w-40"
        style={{ borderColor: "var(--line)" }}
      />
      {mode === "B2B" && (
        <input
          placeholder="Company"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
          className="px-2 py-1 rounded border bg-transparent text-sm w-32"
          style={{ borderColor: "var(--line)" }}
        />
      )}
      <button
        type="submit"
        disabled={submitting}
        className="px-3 py-1 rounded text-sm font-medium"
        style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
      >
        Save
      </button>
      <button type="button" onClick={() => setOpen(false)} className="text-sm" style={{ color: "var(--text-dim)" }}>
        Cancel
      </button>
    </form>
  );
}
