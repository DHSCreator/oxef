import { db } from "@/db";
import { leads, activities, bookings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { LeadActions } from "@/components/lead-actions";

export default async function LeadDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const lead = db.select().from(leads).where(eq(leads.id, id)).get();
  if (!lead) notFound();

  const log = await db
    .select()
    .from(activities)
    .where(eq(activities.leadId, id))
    .orderBy(activities.createdAt);

  const booking = db.select().from(bookings).where(eq(bookings.leadId, id)).get();

  return (
    <div className="max-w-3xl">
      <p className="mono text-xs mb-1" style={{ color: "var(--text-dim)" }}>
        {lead.mode} · {lead.source.replaceAll("_", " ").toLowerCase()}
      </p>
      <h1 className="text-2xl font-semibold mb-6">
        {lead.name || lead.company || lead.email || "Unnamed lead"}
      </h1>

      <div className="grid grid-cols-2 gap-8">
        <div>
          <dl className="text-sm space-y-2 mb-8">
            {lead.email && (
              <div className="flex justify-between border-b pb-2" style={{ borderColor: "var(--line)" }}>
                <dt style={{ color: "var(--text-dim)" }}>Email</dt>
                <dd>{lead.email}</dd>
              </div>
            )}
            {lead.phone && (
              <div className="flex justify-between border-b pb-2" style={{ borderColor: "var(--line)" }}>
                <dt style={{ color: "var(--text-dim)" }}>Phone</dt>
                <dd>{lead.phone}</dd>
              </div>
            )}
            {lead.company && (
              <div className="flex justify-between border-b pb-2" style={{ borderColor: "var(--line)" }}>
                <dt style={{ color: "var(--text-dim)" }}>Company</dt>
                <dd>{lead.company}</dd>
              </div>
            )}
            {lead.industry && (
              <div className="flex justify-between border-b pb-2" style={{ borderColor: "var(--line)" }}>
                <dt style={{ color: "var(--text-dim)" }}>Industry</dt>
                <dd>{lead.industry}</dd>
              </div>
            )}
            {lead.rawMessage && (
              <div className="pt-2">
                <dt className="mb-1" style={{ color: "var(--text-dim)" }}>
                  Original message
                </dt>
                <dd
                  className="p-3 rounded text-xs"
                  style={{ background: "var(--panel)", color: "var(--text-dim)" }}
                >
                  {lead.rawMessage}
                </dd>
              </div>
            )}
          </dl>

          <LeadActions leadId={lead.id} currentStatus={lead.status} booking={booking} />
        </div>

        <div>
          <h2 className="text-sm font-medium mb-3" style={{ color: "var(--text-dim)" }}>
            Activity
          </h2>
          <ul className="space-y-3">
            {log.map((item) => (
              <li key={item.id} className="text-sm">
                <p>{item.message}</p>
                <p className="mono text-xs" style={{ color: "var(--text-dim)" }}>
                  {new Date(item.createdAt).toLocaleString()}
                </p>
              </li>
            ))}
            {log.length === 0 && (
              <p className="text-sm" style={{ color: "var(--text-dim)" }}>
                No activity yet.
              </p>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
