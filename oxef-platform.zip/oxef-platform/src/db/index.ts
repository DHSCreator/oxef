import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "./schema";

const DB_PATH = process.env.DATABASE_URL?.replace("file:", "") || "./dev.db";

declare global {
  // eslint-disable-next-line no-var
  var __sqlite: Database.Database | undefined;
}

const sqlite = global.__sqlite ?? new Database(DB_PATH);
if (process.env.NODE_ENV !== "production") global.__sqlite = sqlite;

sqlite.pragma("journal_mode = WAL");

export const db = drizzle(sqlite, { schema });
