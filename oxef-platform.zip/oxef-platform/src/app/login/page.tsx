"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { signIn } from "next-auth/react";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const callbackUrl = params.get("callbackUrl") || "/dashboard";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    setLoading(false);

    if (res?.error) {
      setError("Email or password is wrong.");
      return;
    }
    router.push(callbackUrl);
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm p-8 rounded-lg border"
        style={{ background: "var(--panel)", borderColor: "var(--line)" }}
      >
        <p className="mono text-xs mb-2" style={{ color: "var(--signal)" }}>
          OXEF / Lead Ops
        </p>
        <h1 className="text-2xl font-semibold mb-6">Sign in</h1>

        <label className="block text-sm mb-1" style={{ color: "var(--text-dim)" }}>
          Email
        </label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full mb-4 px-3 py-2 rounded border bg-transparent"
          style={{ borderColor: "var(--line)" }}
        />

        <label className="block text-sm mb-1" style={{ color: "var(--text-dim)" }}>
          Password
        </label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-6 px-3 py-2 rounded border bg-transparent"
          style={{ borderColor: "var(--line)" }}
        />

        {error && (
          <p className="text-sm mb-4" style={{ color: "var(--bad)" }}>
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 rounded font-medium disabled:opacity-60"
          style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>

        <p className="mt-6 text-xs" style={{ color: "var(--text-dim)" }}>
          No account yet? Seed one with{" "}
          <code className="mono">npm run db:seed</code> — see README.
        </p>
      </form>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
