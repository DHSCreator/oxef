import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col">
      <header className="flex items-center justify-between px-8 py-6 border-b" style={{ borderColor: "var(--line)" }}>
        <span className="mono text-sm tracking-tight" style={{ color: "var(--text-dim)" }}>OXEF / Lead Ops</span>
        <Link
          href="/login"
          className="px-4 py-2 rounded text-sm font-medium"
          style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
        >
          Sign in
        </Link>
      </header>

      <section className="flex-1 flex items-center px-8">
        <div className="max-w-2xl">
          <p className="mono text-sm mb-4" style={{ color: "var(--signal)" }}>
            one inbox for every lead
          </p>
          <h1 className="text-5xl leading-[1.1] font-semibold mb-6">
            Every lead, every channel,
            <br />
            one working queue.
          </h1>
          <p className="text-lg mb-10 max-w-lg" style={{ color: "var(--text-dim)" }}>
            Website forms, email, Instagram DMs and comments, and your Telegram
            bot all land here as a lead — tagged B2B or B2C, ready to follow up
            and book.
          </p>
          <div className="flex gap-3">
            <Link
              href="/login"
              className="px-5 py-3 rounded font-medium"
              style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
            >
              Open dashboard
            </Link>
          </div>
        </div>
      </section>

      <footer className="px-8 py-6 mono text-xs" style={{ color: "var(--text-dim)", borderTop: "1px solid var(--line)" }}>
        OXEF — Lead Generation &amp; Follow-up
      </footer>
    </main>
  );
}
