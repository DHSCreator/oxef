import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  // Disabled: this app's dashboard pages are always dynamic (per-user,
  // per-request DB reads via Drizzle/better-sqlite3), so React Cache
  // Components' prerendering model doesn't fit and only adds friction.
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
