import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/db";
import { leads, activities } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { LEAD_MODES, LEAD_SOURCES } from "@/db/schema";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const mode = req.nextUrl.searchParams.get("mode");
  const status = req.nextUrl.searchParams.get("status");

  const conditions = [];
  if (mode === "B2B" || mode === "B2C") conditions.push(eq(leads.mode, mode));
  if (status) conditions.push(eq(leads.status, status as (typeof leads.status._.data)));

  const rows = await db
    .select()
    .from(leads)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(leads.createdAt));

  return NextResponse.json(rows);
}

const CreateSchema = z.object({
  mode: z.enum(LEAD_MODES),
  source: z.enum(LEAD_SOURCES).default("MANUAL"),
  name: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  company: z.string().optional(),
  industry: z.string().optional(),
  rawMessage: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => null);
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const [lead] = await db.insert(leads).values(parsed.data).returning();

  await db.insert(activities).values({
    leadId: lead.id,
    userId: (session.user as { id?: string })?.id,
    type: "lead_created",
    message: `Lead created manually by ${session.user?.email}`,
  });

  return NextResponse.json(lead, { status: 201 });
}
