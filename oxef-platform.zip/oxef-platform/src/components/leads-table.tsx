"use client";

import Link from "next/link";
import type { InferSelectModel } from "drizzle-orm";
import type { leads } from "@/db/schema";

type Lead = InferSelectModel<typeof leads>;

const STATUS_COLOR: Record<string, string> = {
  NEW: "var(--signal)",
  CONTACTED: "#6ea8ff",
  FOLLOW_UP: "#b58cff",
  BOOKED: "var(--good)",
  WON: "var(--good)",
  LOST: "var(--bad)",
};

export function LeadsTable({ leads }: { leads: Lead[] }) {
  if (leads.length === 0) {
    return (
      <p className="text-sm" style={{ color: "var(--text-dim)" }}>
        No leads match this filter.
      </p>
    );
  }

  return (
    <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--line)" }}>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left" style={{ background: "var(--panel)", color: "var(--text-dim)" }}>
            <th className="px-4 py-3 font-medium">Name</th>
            <th className="px-4 py-3 font-medium">Mode</th>
            <th className="px-4 py-3 font-medium">Source</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium">Created</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <tr
              key={lead.id}
              className="border-t hover:bg-white/5"
              style={{ borderColor: "var(--line)" }}
            >
              <td className="px-4 py-3">
                <Link href={`/dashboard/leads/${lead.id}`} className="hover:underline">
                  {lead.name || lead.company || lead.email || "Unnamed lead"}
                </Link>
                {lead.company && lead.name && (
                  <span className="block text-xs" style={{ color: "var(--text-dim)" }}>
                    {lead.company}
                  </span>
                )}
              </td>
              <td className="px-4 py-3 mono text-xs">{lead.mode}</td>
              <td className="px-4 py-3 text-xs" style={{ color: "var(--text-dim)" }}>
                {lead.source.replaceAll("_", " ").toLowerCase()}
              </td>
              <td className="px-4 py-3">
                <span
                  className="px-2 py-1 rounded text-xs mono"
                  style={{ background: "var(--panel-raised)", color: STATUS_COLOR[lead.status] }}
                >
                  {lead.status}
                </span>
              </td>
              <td className="px-4 py-3 text-xs" style={{ color: "var(--text-dim)" }}>
                {new Date(lead.createdAt).toLocaleDateString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
