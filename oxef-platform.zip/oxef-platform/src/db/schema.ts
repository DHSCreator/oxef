import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

// ---- Enums (stored as text, constrained in app code) ----
export const ROLES = ["ADMIN", "AGENT"] as const;
export const LEAD_MODES = ["B2B", "B2C"] as const;
export const LEAD_SOURCES = [
  "WEBSITE_FORM",
  "EMAIL",
  "INSTAGRAM_DM",
  "INSTAGRAM_COMMENT",
  "TELEGRAM_BOT",
  "MANUAL",
  "OTHER",
] as const;
export const LEAD_STATUSES = [
  "NEW",
  "CONTACTED",
  "FOLLOW_UP",
  "BOOKED",
  "WON",
  "LOST",
] as const;

export type Role = (typeof ROLES)[number];
export type LeadMode = (typeof LEAD_MODES)[number];
export type LeadSource = (typeof LEAD_SOURCES)[number];
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const users = sqliteTable("users", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  name: text("name"),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").$type<Role>().notNull().default("AGENT"),
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

export const leads = sqliteTable("leads", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  mode: text("mode").$type<LeadMode>().notNull(),
  source: text("source").$type<LeadSource>().notNull(),
  status: text("status").$type<LeadStatus>().notNull().default("NEW"),

  name: text("name"),
  email: text("email"),
  phone: text("phone"),
  company: text("company"),
  industry: text("industry"),

  rawMessage: text("raw_message"),

  assignedToId: text("assigned_to_id").references(() => users.id),

  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
  updatedAt: integer("updated_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

export const bookings = sqliteTable("bookings", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  leadId: text("lead_id")
    .notNull()
    .unique()
    .references(() => leads.id, { onDelete: "cascade" }),
  scheduledAt: integer("scheduled_at", { mode: "timestamp" }).notNull(),
  notes: text("notes"),
  confirmed: integer("confirmed", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});

export const activities = sqliteTable("activities", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  leadId: text("lead_id")
    .notNull()
    .references(() => leads.id, { onDelete: "cascade" }),
  userId: text("user_id").references(() => users.id),
  type: text("type").notNull(), // note | status_change | follow_up_sent | booking_created
  message: text("message").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`(unixepoch())`),
});
