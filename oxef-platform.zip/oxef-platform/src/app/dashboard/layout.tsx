import Link from "next/link";
import { auth, signOut } from "@/auth";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  return (
    <div className="min-h-screen flex">
      <aside
        className="w-56 shrink-0 flex flex-col border-r px-4 py-6"
        style={{ borderColor: "var(--line)", background: "var(--panel)" }}
      >
        <p className="mono text-xs mb-8" style={{ color: "var(--signal)" }}>
          OXEF / Lead Ops
        </p>
        <nav className="flex flex-col gap-1 text-sm">
          <Link href="/dashboard" className="px-3 py-2 rounded hover:bg-white/5">
            Overview
          </Link>
          <Link href="/dashboard/leads" className="px-3 py-2 rounded hover:bg-white/5">
            Leads
          </Link>
          <Link href="/dashboard/leads?mode=B2B" className="px-3 py-2 rounded hover:bg-white/5 text-xs ml-2" style={{ color: "var(--text-dim)" }}>
            → B2B
          </Link>
          <Link href="/dashboard/leads?mode=B2C" className="px-3 py-2 rounded hover:bg-white/5 text-xs ml-2" style={{ color: "var(--text-dim)" }}>
            → B2C
          </Link>
        </nav>

        <div className="mt-auto pt-6 border-t text-xs" style={{ borderColor: "var(--line)" }}>
          <p className="mb-2" style={{ color: "var(--text-dim)" }}>
            {session?.user?.email}
          </p>
          <form
            action={async () => {
              "use server";
              await signOut({ redirectTo: "/" });
            }}
          >
            <button className="underline" style={{ color: "var(--text-dim)" }}>
              Sign out
            </button>
          </form>
        </div>
      </aside>

      <main className="flex-1 px-10 py-8">{children}</main>
    </div>
  );
}
