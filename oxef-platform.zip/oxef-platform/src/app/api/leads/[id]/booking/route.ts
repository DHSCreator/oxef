import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/db";
import { bookings, leads, activities } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

const BookingSchema = z.object({
  scheduledAt: z.string(), // ISO date string
  notes: z.string().optional(),
});

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = BookingSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const [booking] = await db
    .insert(bookings)
    .values({
      leadId: id,
      scheduledAt: new Date(parsed.data.scheduledAt),
      notes: parsed.data.notes,
    })
    .returning();

  await db.update(leads).set({ status: "BOOKED", updatedAt: new Date() }).where(eq(leads.id, id));

  await db.insert(activities).values({
    leadId: id,
    userId: (session.user as { id?: string })?.id,
    type: "booking_created",
    message: `Booking scheduled for ${parsed.data.scheduledAt}`,
  });

  return NextResponse.json(booking, { status: 201 });
}
