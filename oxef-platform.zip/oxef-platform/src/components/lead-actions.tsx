"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LEAD_STATUSES } from "@/db/schema";

type Booking = { scheduledAt: Date | string; notes?: string | null; confirmed: boolean } | null | undefined;

export function LeadActions({
  leadId,
  currentStatus,
  booking,
}: {
  leadId: string;
  currentStatus: string;
  booking: Booking;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(currentStatus);
  const [note, setNote] = useState("");
  const [scheduledAt, setScheduledAt] = useState("");
  const [busy, setBusy] = useState(false);

  async function updateStatus(newStatus: string) {
    setBusy(true);
    setStatus(newStatus);
    await fetch(`/api/leads/${leadId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    setBusy(false);
    router.refresh();
  }

  async function addNote(e: React.FormEvent) {
    e.preventDefault();
    if (!note.trim()) return;
    setBusy(true);
    await fetch(`/api/leads/${leadId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ note }),
    });
    setNote("");
    setBusy(false);
    router.refresh();
  }

  async function createBooking(e: React.FormEvent) {
    e.preventDefault();
    if (!scheduledAt) return;
    setBusy(true);
    await fetch(`/api/leads/${leadId}/booking`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scheduledAt: new Date(scheduledAt).toISOString() }),
    });
    setBusy(false);
    router.refresh();
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm mb-2" style={{ color: "var(--text-dim)" }}>
          Status
        </p>
        <div className="flex flex-wrap gap-2">
          {LEAD_STATUSES.map((s) => (
            <button
              key={s}
              disabled={busy}
              onClick={() => updateStatus(s)}
              className="px-3 py-1 rounded text-xs mono"
              style={{
                background: s === status ? "var(--signal)" : "var(--panel)",
                color: s === status ? "var(--accent-ink)" : "var(--text-dim)",
                border: "1px solid var(--line)",
              }}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={addNote} className="space-y-2">
        <p className="text-sm" style={{ color: "var(--text-dim)" }}>
          Add note (e.g. follow-up sent)
        </p>
        <div className="flex gap-2">
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="flex-1 px-3 py-2 rounded border bg-transparent text-sm"
            style={{ borderColor: "var(--line)" }}
            placeholder="Sent follow-up via email…"
          />
          <button
            type="submit"
            disabled={busy}
            className="px-3 py-2 rounded text-sm font-medium"
            style={{ background: "var(--panel-raised)", border: "1px solid var(--line)" }}
          >
            Add
          </button>
        </div>
      </form>

      <div>
        <p className="text-sm mb-2" style={{ color: "var(--text-dim)" }}>
          Booking
        </p>
        {booking ? (
          <p className="text-sm">
            Scheduled for{" "}
            <span className="mono">{new Date(booking.scheduledAt).toLocaleString()}</span>
            {booking.confirmed ? (
              <span style={{ color: "var(--good)" }}> · confirmed</span>
            ) : (
              <span style={{ color: "var(--signal)" }}> · pending</span>
            )}
          </p>
        ) : (
          <form onSubmit={createBooking} className="flex gap-2">
            <input
              type="datetime-local"
              value={scheduledAt}
              onChange={(e) => setScheduledAt(e.target.value)}
              className="px-3 py-2 rounded border bg-transparent text-sm"
              style={{ borderColor: "var(--line)" }}
            />
            <button
              type="submit"
              disabled={busy}
              className="px-3 py-2 rounded text-sm font-medium"
              style={{ background: "var(--signal)", color: "var(--accent-ink)" }}
            >
              Schedule
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
